﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Coalition
{
    public class InGamePlayer
    {
        public string nick;
        public string role;
        public string weight;
        public string offer;
        public string hash;
    }
}